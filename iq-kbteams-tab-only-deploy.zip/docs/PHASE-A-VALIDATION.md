# Phase A validation

Date: 2026-10-03. Environment: Windows host with Docker Desktop Linux engine 29.7.2; Linux container engine reported 9.716 GiB available memory.

This is the initial Phase A scaffold snapshot, before the Phase B and Phase C implementation checkpoints. Its “Not validated” items describe the state at this checkpoint; see [PHASE-C-VALIDATION.md](PHASE-C-VALIDATION.md) for the later implementation and test evidence, plus the remaining release gates.

## Passed

- `go build ./...` and `go vet ./...` using Go 1.27.1.
- Frontend lockfile install and production build. Local Node 22 emitted the expected engine warning; the Docker build succeeded on Node 24.
- Gateway lockfile install and TypeScript build; gateway Docker image built and started with temporary local-only credentials.
- Go app Docker image built with embedded React assets; parser image built with Python 3.12 and pinned packages.
- `docker compose config --quiet` passed with temporary non-tenant configuration values.
- App, gateway, parser, and Caddy started with local-only placeholder identity and client secrets. Readiness returned `{"status":"ready"}` through local HTTPS. A malformed unauthenticated `POST /api/messages` returned 401.
- Restarted the Go app against the same SQLite volume and encryption key; it returned ready afterward, confirming the persisted AES-GCM key check survived restart.
- Parser container inspection confirmed read-only root, `network_mode: none`, 512 MiB memory, one CPU, and a 64 process limit. Only Caddy publishes host ports 80 and 443.

## Initial idle snapshot

This is the scaffold with no user traffic, model calls, or parser jobs. Docker stats are a one-time snapshot, not a load test.

| Component | Docker stats memory | Process RSS where measured |
|---|---:|---:|
| Go app | 5.16 MiB | 12,168 KiB (`/proc/1/status`) |
| Teams gateway | 44.96 MiB | — |
| Parser | 13.02 MiB | — |
| Caddy | 18.24 MiB | — |

The Go process is below the initial 128 MiB idle RSS target in this snapshot. Parser peak memory and concurrent asks are unmeasured.

## Not validated

- Real Entra or Bot registration, tenant consent, public HTTPS hostname, Teams install, Teams SSO/OBO, Graph calls, or source permissions.
- SharePoint and OneDrive retrieval, Teams messages, Outlook, PostgreSQL, provider requests, shared-answer proof, or private handoff.
- Parser extraction behavior or archive/input/time limits; the parser is still a socket placeholder.
- User-facing ask and admin workflows. The session verifier and protected setup-status/bootstrap gate have since been added, but no live tenant auth or setup wizard has been exercised. Ask/admin business functions remain unavailable.
- Whole-stack latency and peak-memory under synthetic or real load.

The local startup used dummy IDs and temporary random keys in ignored scratch files. It made no external tenant calls and is not evidence of live Teams compatibility. The temporary containers, volumes, and scratch credentials are for this local check only.
