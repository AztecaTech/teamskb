# One-container Dokploy deployment

Use `compose.dokploy.yaml` in **Docker Compose** mode, backed by this Git repository. This builds one container containing the Go app, TypeScript Teams gateway, Python parser, and Caddy router. Docker Stack mode does not support this source build.

The root `Dockerfile` builds the same image directly with `docker build -t iq-kbteams-single:local .`. Use Compose to supply its runtime environment, persistent volumes, and process security settings.

1. Select the repository and set the Compose path to `compose.dokploy.yaml`.
2. Paste `.env.dokploy.example` into Dokploy's **Environment** editor and fill the required values. Dokploy writes `.env`; `env_file: .env` injects it at runtime. It is never copied into the image or passed as build arguments. Preserve quotes for passwords containing special characters and redeploy after changing configuration. Do not set legacy `*_FILE` paths: this variant receives values directly.
3. Generate three distinct 32-byte random keys, each encoded as 64 hex characters, for `APP_ENCRYPTION_KEY`, `BRIDGE_HMAC_KEY`, and `MSAL_CACHE_KEY_HEX`. For example, run `openssl rand -hex 32` separately for each key. Keep them stable and backed up securely. Changing the app encryption key makes existing app data unreadable.
4. Under **Domains**, select service **iqkb**, container port **8088**, and enable HTTPS. Set `PUBLIC_ORIGIN` to that exact public HTTPS origin. Dokploy/Traefik terminates TLS; Caddy routes internal HTTP to the Go API or Teams callback gateway. There are no host bindings for 80/443 and no public routes to Go port 8080 or gateway port 3978.
5. Deploy. The healthcheck covers the four processes. Follow `SETUP.md` for Entra registrations, bot callbacks, consent, Teams packaging, and first-admin activation. `APP_ID_URI` is a registration/package value, not required by this runtime image.
6. Keep a single running replica. Back up named volumes `app_data` and `gateway_cache` plus encryption keys separately. Persist the Dokploy Compose project identity across redeployments. Migrating from the four-container stack requires preserving/restoring its app metadata and MSAL cache; a new Compose project creates new volumes.

PostgreSQL remains an optional external source. `POSTGRES_DSN` is a server connection template using verified TLS, not a shared database execution identity. Per-user database passwords still come through the authenticated app setup. Publicly trusted certificates use the image CA bundle. A private CA requires an additional read-only file mount and `sslrootcert` pointing to its container path; do not turn certificate verification off.

Caddy rejects public request bodies over 2 MiB and aborts uploads that stall for 10 seconds (or exceed the 30-second total body deadline). The Go app independently limits request bodies to 1 MiB and reads to 15 seconds. The 2 MiB edge limit accommodates a Teams image of up to 1 MiB when base64-encoded with activity metadata; larger or multiple inline attachments can still be rejected.

## Process and security behavior

For a tab-only pilot, set `BOT_ENABLED=false`. Leave `BOT_CLIENT_ID` and `BOT_CLIENT_SECRET` empty; the gateway still runs the private Graph OBO service using `APP_CLIENT_ID` and `APP_CLIENT_SECRET`. Azure Bot and its OAuth connection are unnecessary in this mode. Generate the Teams package with `scripts/package-teams-app.ps1 -TabOnly` and the remaining package parameters. Use the exact Application ID URI already configured in Entra; the tab-only packager accepts the existing host/botid-GUID resource or a host/API-GUID resource. The package omits the bot while keeping its code and template available. Restore `BOT_ENABLED=true` and install a bot-enabled package when ready to test messaging.

The root launcher starts non-root children, removes unrelated environment variables from each child's environment, monitors process exits, and stops all children on termination. Docker's tiny init reaps orphaned descendants. If any service exits, the container exits with failure and Compose restarts it. A healthcheck failure alone marks the container unhealthy; it does not automatically restart a hung service.

The Go and gateway processes use UID 65532 and bind their TCP ports to loopback. They share an identity for their private socket and are not isolated from each other's files or process environments. Caddy runs as UID 65533. The parser runs as UID 65534, receives no app secrets, cannot traverse the app/cache directories, and has a 512 MiB virtual-address-space limit. A fail-closed libseccomp filter permits Unix sockets but rejects creation of other socket families. Parser extraction's existing archive, size, structural and time limits remain active. Its socket is group-accessible only to the app identity. No privileged mode, host networking, Docker socket, or added SYS_ADMIN capability is used.

This provides **less isolation than the original separate parser container**: all processes share a filesystem, container resource limit, and network namespace. The seccomp socket filter is a process restriction, not a separate network namespace. UID boundaries and environment filtering do not conceal injected secrets from Docker/Dokploy administrators, who can inspect container configuration. Hostile-document testing and live Microsoft permission tests remain required. Source allocation now reserves a bounded slot for each of six enabled source families.

For local testing, copy the template to ignored `.env`, fill it, and run `docker compose -f compose.dokploy.yaml up --build -d`. Access requires an external proxy because no host port is published. `scripts/validate-single-container.ps1` instead uses synthetic configuration, a temporary loopback test port, and disposable volumes, then cleans them up.

## Local verification

The combined image built successfully. Go tests passed, the frontend production bundle built, and the gateway's 17 tests passed in the Linux image build. The synthetic single-container validation passed environment injection (including a quoted `$` value), non-root identities with zero child effective capabilities, per-process secret filtering, anonymous API and unsigned Teams activity rejection, proxy headers, text extraction, parser network-socket denial, parser denial of access to the app database, a saved metadata marker surviving restart, and restart after killing the Go child. The fixture was removed afterward. These checks do not establish a live Dokploy deployment, Microsoft tenant compatibility, or production hostile-document resistance.

## Research references

- [Dokploy environment injection and Compose deployment](https://docs.dokploy.com/docs/core/docker-compose): `.env` is not injected without `env_file` or explicit environment mappings; named volumes support persistent state.
- [Dokploy Compose domains](https://docs.dokploy.com/docs/core/docker-compose/domains): route the domain to the selected service and its container port.
- [Docker multiple-process containers](https://docs.docker.com/engine/containers/multi-service_container/): the launcher manages child lifecycle, with `init: true` for reaping.
