# Dummy-data validation and security revalidation

Review started 2026-10-03 Pacific time. This follows the historical `SECURITY-REVIEW-2026-10-03.md`. Tests used synthetic documents, fake Microsoft responses, a local model response fixture, and disposable PostgreSQL users/data. No company content or real model account was used.

Local validation passed. The four earlier findings are addressed in the inspected implementation. An independent Astra audit found a medium availability issue and a source-allocation bug; both are addressed locally in the findings below, with large-tenant performance and live Microsoft/production-permission checks still open. Luna verified the main implementation claims while distinguishing local fixtures from live-service evidence. Live Microsoft compatibility and production permissions remain release gates. No demonstrated critical/high authentication bypass was found within this review's scope.

## Checks performed independently

| Check | Result and scope |
| --- | --- |
| `go test -count=1 ./...` | Passed on Windows. Unix-socket and external PostgreSQL tests require their separate fixtures. |
| `go vet ./...` | Passed. |
| Linux `go test -race -count=1 -v ./...` | Passed with no race detector findings. The authenticated dummy ask used the real PDF parser over a shared Unix socket, controlled Graph/OBO fixtures, and the actual OpenAI-compatible SDK against a local HTTPS response fixture. Synthetic answer and citation assertions passed. Database integration cases skipped in this run were exercised separately by the PostgreSQL script. |
| Gateway `npm test` | 16 passed, one Unix-socket test skipped on Windows. TypeScript build passed. |
| Frontend `npm run build` | TypeScript and Vite production build passed. |
| `validate-compose-build.ps1` | Passed: current app/gateway/parser images built, 16 parser tests ran with production isolation restrictions, readiness succeeded, anonymous sessions returned 401, resource limits matched. Cached Docker build steps do not constitute a fresh Linux gateway test run. |
| `validate-postgres-integration.ps1` | Passed against disposable PostgreSQL 18 with verified TLS: two actual LOGIN users, RLS row isolation, column grants, write rejection, query/lock timeouts, authenticated ask workflow, password rotation, and NOLOGIN revocation. Test tables/users belong only to the throwaway fixture. |
| `validate-caddy-headers.ps1` | Passed: HTTPS responses contained the expected CSP and other headers. The probe does not validate production certificates or live Teams embedding. |
| `validate-teams-package.ps1` | Passed synthetic manifest/ZIP/URI checks. This is not Microsoft app-catalog validation or installation. |
| `govulncheck ./...` via `go run` | No vulnerabilities found. |
| `pip-audit -r parser/requirements.txt` in a disposable container | No known vulnerabilities found. |
| Production npm audits, frontend and gateway | Zero listed vulnerabilities. Development dependencies and container OS packages are outside these npm audit results. |

## Earlier findings

| Finding | Current evidence | Status |
| --- | --- | --- |
| SEC-01: missing concurrency/model-attempt controls | `usage.go:21–23,64,89`; production main shares one gate at `main.go:190`; ask and provider-check routes reserve attempts before invocation. Concurrent reservations and rejection are regression-tested. | Addressed for the supported single-process deployment. Default monthly cap is 10,000 attempts; configurable, and not a token/spend ceiling. |
| SEC-02: slow-body protection | `main.go:44–45,255–256`: 15-second request reads, 180-second writes, 150-second processing. TCP trickle regression passed. | Addressed locally; authenticated end-to-end behavior through Caddy remains a live deployment check. |
| SEC-03: provider redirects | `app/internal/answer/model.go:39`: redirects refused. SDK regression tests assert 307/308 destinations receive no request. | Addressed. |
| SEC-04: stale credential save following remap | `postgres_admin.go:251–277`: rechecks the email/identity binding and writes the encrypted password in one SQLite transaction. Current/stale binding tests passed. | Original race addressed. Broader concurrent remap/revocation scenarios remain pilot tests. |

## Current medium security finding

### SEC-05 — Rejected requests could cause unbounded audit writes

Status: addressed locally on 2026-10-05. Ask audit events are recorded only after the per-user daily quota admits a request, so concurrency-limit and daily-quota rejections do not insert one persistent row per attempt. Audits for admitted requests use a two-second deadline, and migration 008 adds transactional row accounting with a 100,000-row total cap that evicts the oldest event first. A per-user ask token bucket now allows a burst of 10, refills at one request per second, and runs after token verification but before the SQLite role lookup; tracked identity state is capped at 16,384 entries and fails closed at capacity. Tests cover refill, state-cap enforcement, and rejection before the DB lookup. Token verification still runs on each request, so this is not a network-flood defense. `TestAskWorkflowRejectsOverlappingRequestsWithoutWaiting` and `TestAskWorkflowDoesNotAuditRepeatedDailyQuotaRejections` each repeat 20 rejected requests and assert that no audit rows are added; `TestRecordAskAuditEnforcesGlobalCapacity`, `TestPruneAuditEventCapacityKeepsNewestRows`, and `TestAuditCapacityMigrationCountsExistingEvents` cover insertion/cleanup pruning and upgrade accounting. Large-tenant storage and rate-state performance remain unverified.

Original evidence at discovery: `app/cmd/iqkb/ask.go` scheduled `recordAskAudit(context.Background(), ...)` before the admission check, and `app/cmd/iqkb/usage.go` inserted a fresh row for every request, including concurrency/quota rejections. No request rate limiter is configured in the supplied Caddyfile.

Original impact: an authenticated tenant user could keep submitting valid questions after receiving HTTP 429, forcing persistent SQLite writes despite the ask limits. Thirty-day retention bounded age, not event count. Audit writes used an uncancelled background context without a deadline. Storage-exhaustion throughput was not reproduced or measured.

Original recommendation: coalesce or rate-bound rejected-request events, apply a short audit-write deadline, and enforce a finite storage policy. Preserve meaningful security events without storing one row per rejected attempt indefinitely. Add a controlled test that repeated rejected requests do not produce proportional persistent writes.

## Separate functional finding

### FUNC-01 — All six enabled sources starve PostgreSQL

Status: addressed locally. Retrieval now has six candidate slots, with `sourceLimits` distributing at least one to each enabled source. `TestSourceLimitsDivideAnswerBudgetAcrossEnabledSources` covers five and six enabled sources and asserts the PostgreSQL slot is nonzero when all six are enabled. The total retrieval budget remains bounded at six. This test verifies allocation, not live relevance ranking or Graph/PostgreSQL service behavior; validate retrieval against the intended tenant and database before relying on source coverage.

## Remaining gates and limits

1. Live Teams SSO, bot OAuth, Graph OBO, consent, and revoked Microsoft access remain untested. Controlled issuer/JWKS tests exercise signature, audience, tenant, scope, expiry, and client checks, but cannot establish Microsoft compatibility.
2. PostgreSQL email binding requires the configured `verified_primary_email` claim; missing claims fail closed for that source. Its availability must be verified with the intended tenant accounts. Microsoft documents it as an [optional claim](https://learn.microsoft.com/en-us/entra/identity-platform/optional-claims-reference). Identity and source authorization still use stable tenant/object IDs and original source permissions.
3. Group/channel bot requests produce a private-tab handoff. Shared answers and verification of every recipient against every evidence item are not implemented. This is a capability gap, not a demonstrated shared-data leak.
4. Validate the actual organization's PostgreSQL roles, RLS, views/functions, and DBA-approved query catalog. The SELECT validator is a guardrail, not a substitute for database permissions and DBA review. PostgreSQL OAuth remains unsupported.
5. Source-derived citation-shaped tokens are normalized before prompt assembly so retrieved text cannot forge `[S1]` labels. Mock model replies still demonstrate API wiring and citation rejection, not factual grounding or resistance to other adversarial document instructions in a real model; citation labels do not establish that the cited source supports the answer.
6. Retrieved evidence goes to the selected model provider. Storage flags do not prove provider retention behavior; configure and validate the intended provider policy.
7. Apply production resource/load tests and secret-file permissions. Encrypted local metadata requires separately protected encryption keys and backups. SQLite is app state, not a copied knowledge base; no additional database is required.

No production deployment, release approval, or real-service security certification follows from these local checks.

All disposable containers and named volumes created for this revalidation were cleaned up; unrelated running containers were left alone. No application implementation changes were made during the review. The first audit document is now marked historical to avoid presenting resolved findings as current.
