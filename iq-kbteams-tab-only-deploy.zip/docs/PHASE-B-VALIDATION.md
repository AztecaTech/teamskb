# Phase B implementation notes

Date: 2026-10-03. This is a local implementation checkpoint, not a live Microsoft 365 compatibility result.

## Implemented in this checkpoint

- Teams tab initializes TeamsJS 2.57.0, requests SSO with `authentication.getAuthToken()` after initialization, and sends the token only in an `Authorization` header to the Go session endpoint. It does not write the token to browser storage.
- The authenticated view shows the assigned `Admin` or `User` role. Admins can see whether setup is active; no connector/provider setup controls exist yet.
- The app's authenticated private bridge route can forward a JSON extraction request to the parser over the parser Unix socket. The route is behind the existing timestamped HMAC, replay-protected app/gateway bridge.
- The parser supports PDF, DOCX, PPTX, and XLSX, runs without network access as a non-root user, and enforces 24 MiB input, 128 MiB OOXML expansion, 100:1 archive ratio, page/slide/sheet/cell, and 2,000,000 character limits. It rejects encrypted and unsupported documents. It does not persist text.
- The gateway now accepts OBO requests only on a mode-0600 Unix socket shared with the Go app. It fixes the requested scope to delegated `https://graph.microsoft.com/Files.Read`; callers cannot select scopes, and MSAL details are not returned. The app exposes an admin-only OneDrive access check.
- The Go OneDrive connector searches only `/me/drive`, downloads a maximum of five supported matches up to 24 MiB each, obtains the access token through the gateway socket, and limits citation URLs to HTTPS SharePoint/OneDrive domains. Graph rechecks user access on each search/download. Search/download is a backend package and is not yet wired to the answer endpoint.

## Validation performed

- Frontend production build with Node 24 in the application image passed; local build also passed using Node 22 with its declared engine warning.
- Go app image built. Native `go build ./...` and `go vet ./...` passed after the internal parser route was added.
- Parser Docker image built. Six `unittest` cases passed inside that pinned image, covering DOCX/PPTX/XLSX extraction and input/type/archive expansion rejections.
- Compose recreated the app and parser. Readiness through local Caddy HTTPS returned `{"status":"ready"}`; the embedded tab page served the latest JS/CSS. Unauthenticated `/api/session` and `/api/setup/status` requests returned 401.
- A post-start idle Docker stats snapshot showed the parser at 41.13 MiB and Go app at 7.55 MiB. This measures idle-after-import memory only; no document peak, concurrency, or load test was performed.

## Still unimplemented or unverified

- No real Entra tenant token, Teams client, public hostname, app registration, Teams installation, OBO exchange, or Graph request has been tested.
- No Teams activity reaches an answer workflow yet. The app `/api/ask` and admin business routes remain unavailable; parser bridge has no source connector caller.
- Setup activation remains intentionally blocked until connector, provider, identity, and source checks are implemented. The bootstrap secret gate does not configure or activate the service.
- SharePoint/OneDrive, Teams messages, Outlook, provider requests, shared answer audience proofs, and PostgreSQL mapping/query behavior remain unimplemented.
- Extraction omits some office features (including embedded media/OCR, workbook formulas without cached values, and non-body document content). No test yet covers PDFs with extracted text, encrypted PDFs, parser socket end-to-end calls, decompression CPU time, or hostile malformed file corpora.
- These implementation changes do not support a claim of release readiness or live permission enforcement.

## Additional validation after the initial Phase B checkpoint

- Four OBO tests pass in the pinned Node 24 Docker build, including a real Unix-socket request and socket-mode check. Three additional OBO payload tests pass on the Windows host; its Unix-socket case is explicitly skipped there.
- Four OneDrive Go tests pass with mocked Graph responses, covering delegated auth header use, search/download of supported content, query bounds, file-size bounds, and citation URL host checks.
- App and gateway Docker images build. The gateway image build runs the OBO tests in Linux before producing the runtime image.
- Compose config with nonempty dummy values passes after adding OBO. The updated full stack starts, readiness returns `{"status":"ready"}`, and the gateway OBO socket is mode `0600`. The unauthenticated setup endpoint returns 401. No actual tenant assertion or delegated Graph call has been made.
