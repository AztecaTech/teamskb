-- DISPOSABLE INTEGRATION DATABASE ONLY. This fixture creates two actual
-- LOGIN users with separate SELECT privileges and forced row-level security.
-- Passwords are test-only; never use them outside this disposable database.
CREATE ROLE iqkb_alex_login LOGIN PASSWORD 'IQKB-TEST-ONLY-Alex-1234!';
CREATE ROLE iqkb_blair_login LOGIN PASSWORD 'IQKB-TEST-ONLY-Blair-5678!';
CREATE SCHEMA iqkb_fixture;
CREATE TABLE iqkb_fixture.documents (
  id text PRIMARY KEY,
  title text NOT NULL,
  content text NOT NULL,
  source_url text NOT NULL,
  owner_login name NOT NULL,
  alex_private text NOT NULL
);
ALTER TABLE iqkb_fixture.documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE iqkb_fixture.documents FORCE ROW LEVEL SECURITY;
CREATE POLICY documents_owner_policy ON iqkb_fixture.documents
  USING (owner_login = current_user)
  WITH CHECK (owner_login = current_user);
GRANT USAGE ON SCHEMA iqkb_fixture TO iqkb_alex_login, iqkb_blair_login;
GRANT SELECT (id, title, content, source_url, owner_login, alex_private)
  ON iqkb_fixture.documents TO iqkb_alex_login;
GRANT SELECT (id, title, content, source_url, owner_login)
  ON iqkb_fixture.documents TO iqkb_blair_login;
INSERT INTO iqkb_fixture.documents(id,title,content,source_url,owner_login,alex_private) VALUES
  ('alex-1','iqkb_alex_login policy','Alex retention policy','https://kb.example.test/alex','iqkb_alex_login','Alex-only column'),
  ('blair-1','iqkb_blair_login policy','Blair retention policy','https://kb.example.test/blair','iqkb_blair_login','Blair row private to Alex');

-- Generic non-document business records exercise discovery/profile queries.
CREATE TABLE iqkb_fixture.ops_assets (
  asset_key text PRIMARY KEY,
  display_name text NOT NULL,
  lifecycle_state text NOT NULL,
  last_seen timestamptz NOT NULL,
  due_date date NOT NULL,
  owner_login name NOT NULL,
  restricted_note text NOT NULL
);
COMMENT ON TABLE iqkb_fixture.ops_assets IS 'Disposable inventory-like business records.';
COMMENT ON COLUMN iqkb_fixture.ops_assets.restricted_note IS 'Must not be discoverable to Blair.';
ALTER TABLE iqkb_fixture.ops_assets ENABLE ROW LEVEL SECURITY;
ALTER TABLE iqkb_fixture.ops_assets FORCE ROW LEVEL SECURITY;
CREATE POLICY ops_assets_owner_policy ON iqkb_fixture.ops_assets USING(owner_login=current_user);
GRANT SELECT (asset_key,display_name,lifecycle_state,last_seen,due_date,owner_login,restricted_note) ON iqkb_fixture.ops_assets TO iqkb_alex_login;
GRANT SELECT (asset_key,display_name,lifecycle_state,last_seen,due_date,owner_login) ON iqkb_fixture.ops_assets TO iqkb_blair_login;
INSERT INTO iqkb_fixture.ops_assets VALUES
  ('asset-alex','Field Laptop','active','2026-10-05 12:00:00.123456-07','2026-10-06','iqkb_alex_login','Alex-only asset note'),
  ('asset-alex-duplicate','Field Laptop','active','2026-10-05 12:00:00-07','2026-10-06','iqkb_alex_login','Duplicate label fixture'),
  ('asset-blair','Warehouse Scanner','retired','2026-10-05 19:00:00+00','2026-10-07','iqkb_blair_login','Blair-only asset note'),
  ('asset-spanish','Documentos confidenciales','active','2026-10-05 12:00:00+00','2026-10-06','iqkb_alex_login','Spanish full-text fixture');

CREATE TABLE iqkb_fixture.ops_asset_events (
  event_id text PRIMARY KEY,
  asset_key text NOT NULL REFERENCES iqkb_fixture.ops_assets(asset_key),
  event_name text NOT NULL,
  priority integer NOT NULL,
  event_url text
);
GRANT SELECT (event_id,asset_key,event_name,priority,event_url) ON iqkb_fixture.ops_asset_events TO iqkb_alex_login, iqkb_blair_login;
INSERT INTO iqkb_fixture.ops_asset_events VALUES ('event-1','asset-alex','assigned',2,'https://assets.example.test/events/event-1'),('event-2','asset-alex','inspection',1,'javascript:alert(1)');

-- Discovery must flag owner-executed views and hide objects with no SELECT.
CREATE VIEW iqkb_fixture.ops_assets_owner_view AS
  SELECT asset_key,display_name FROM iqkb_fixture.ops_assets;
GRANT SELECT ON iqkb_fixture.ops_assets_owner_view TO iqkb_alex_login;
CREATE MATERIALIZED VIEW iqkb_fixture.ops_assets_materialized_view AS
  SELECT asset_key,display_name FROM iqkb_fixture.ops_assets;
GRANT SELECT ON iqkb_fixture.ops_assets_materialized_view TO iqkb_alex_login;
CREATE VIEW iqkb_fixture.ops_assets_invoker_view WITH (security_invoker=true) AS
  SELECT asset_key,display_name,lifecycle_state,owner_login FROM iqkb_fixture.ops_assets;
GRANT SELECT ON iqkb_fixture.ops_assets_invoker_view TO iqkb_alex_login, iqkb_blair_login;
CREATE VIEW iqkb_fixture.ops_assets_duplicate_key_view WITH (security_invoker=true) AS
  SELECT asset_key,display_name,lifecycle_state,owner_login FROM iqkb_fixture.ops_assets
  UNION ALL SELECT asset_key,display_name,lifecycle_state,owner_login FROM iqkb_fixture.ops_assets;
GRANT SELECT ON iqkb_fixture.ops_assets_duplicate_key_view TO iqkb_alex_login;
CREATE FUNCTION iqkb_fixture.volatile_label(text) RETURNS text LANGUAGE sql VOLATILE AS $$ SELECT $1 $$;
CREATE VIEW iqkb_fixture.ops_assets_unsafe_function_view WITH (security_invoker=true) AS
  SELECT asset_key,iqkb_fixture.volatile_label(display_name) AS display_name FROM iqkb_fixture.ops_assets;
GRANT SELECT ON iqkb_fixture.ops_assets_unsafe_function_view TO iqkb_alex_login;
CREATE VIEW iqkb_fixture.ops_assets_nested_definer_view WITH (security_invoker=true) AS
  SELECT asset_key,display_name FROM iqkb_fixture.ops_assets_owner_view;
GRANT SELECT ON iqkb_fixture.ops_assets_nested_definer_view TO iqkb_alex_login;
CREATE TABLE iqkb_fixture.alex_owned_unforced (asset_key text PRIMARY KEY, display_name text NOT NULL);
INSERT INTO iqkb_fixture.alex_owned_unforced VALUES ('owned-1','Owner bypass fixture');
ALTER TABLE iqkb_fixture.alex_owned_unforced OWNER TO iqkb_alex_login;
ALTER TABLE iqkb_fixture.alex_owned_unforced ENABLE ROW LEVEL SECURITY;
CREATE VIEW iqkb_fixture.ops_assets_owner_rls_view WITH (security_invoker=true) AS
  SELECT asset_key,display_name FROM iqkb_fixture.alex_owned_unforced;
GRANT SELECT ON iqkb_fixture.ops_assets_owner_rls_view TO iqkb_alex_login;
CREATE TABLE iqkb_fixture.write_only_records (record_id text PRIMARY KEY, secret text NOT NULL);
GRANT INSERT ON iqkb_fixture.write_only_records TO iqkb_alex_login;
