-- IQ-kbteams does not install or modify organizational PostgreSQL schema,
-- roles, grants, policies, views, or data. This file is a catalog-entry
-- example only. A DBA must adapt and approve a fixed SELECT over existing
-- authorized views/tables and install it in the IQ-kbteams admin catalog.
--
-- Required result columns, in order, must be text-compatible:
--   id, title, content, source_url
-- Required bound parameters:
--   $1 = question text, $2 = integer result limit (1..5)
--
-- Example only; organization.example_knowledge_view must already exist and
-- enforce the organization's access policy for the authenticated login.
SELECT id::text AS id,
       title::text AS title,
       content::text AS content,
       source_url::text AS source_url
FROM organization.example_knowledge_view
WHERE content ILIKE '%' || $1 || '%'
ORDER BY id
LIMIT $2;
