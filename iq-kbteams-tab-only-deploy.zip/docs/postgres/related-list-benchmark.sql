\timing on
CREATE TABLE benchmark_parents (id integer PRIMARY KEY);
INSERT INTO benchmark_parents SELECT n FROM generate_series(1, 10000) AS n;
CREATE TABLE benchmark_children (id bigint PRIMARY KEY, parent_id integer NOT NULL, status text NOT NULL);
INSERT INTO benchmark_children
SELECT n, CASE WHEN n > 999000 THEN 10000 ELSE (n % 9999) + 1 END,
       CASE WHEN n % 2 = 0 THEN 'open' ELSE 'closed' END
FROM generate_series(1, 1000000) AS n;
CREATE INDEX benchmark_children_parent_idx ON benchmark_children(parent_id);
ANALYZE benchmark_children;

\echo RELATED LIST WITH FK CAST TO TEXT
EXPLAIN (ANALYZE, BUFFERS, SUMMARY)
SELECT id, status FROM benchmark_children
WHERE parent_id::text = '10000'
ORDER BY id LIMIT 5;

\echo RELATED LIST WITH TYPED FK BIND
EXPLAIN (ANALYZE, BUFFERS, SUMMARY)
SELECT id, status FROM benchmark_children
WHERE parent_id = '10000'::integer
ORDER BY id LIMIT 5;

\echo RELATED LIST WITH WIDER PARENT KEY TYPE
EXPLAIN (ANALYZE, BUFFERS, SUMMARY)
SELECT id, status FROM benchmark_children
WHERE parent_id = '10000'::bigint
ORDER BY id LIMIT 5;

CREATE INDEX benchmark_children_parent_id_idx ON benchmark_children(parent_id,id);
ANALYZE benchmark_children;

\echo RELATED LIST WITH FK CAST AND COMPOSITE INDEX
EXPLAIN (ANALYZE, BUFFERS, SUMMARY)
SELECT id, status FROM benchmark_children
WHERE parent_id::text = '10000'
ORDER BY id LIMIT 5;

\echo RELATED LIST WITH TYPED FK BIND AND COMPOSITE INDEX
EXPLAIN (ANALYZE, BUFFERS, SUMMARY)
SELECT id, status FROM benchmark_children
WHERE parent_id = '10000'::integer
ORDER BY id LIMIT 5;

\echo RELATED LIST WITH WIDER PARENT KEY TYPE AND COMPOSITE INDEX
EXPLAIN (ANALYZE, BUFFERS, SUMMARY)
SELECT id, status FROM benchmark_children
WHERE parent_id = '10000'::bigint
ORDER BY id LIMIT 5;
