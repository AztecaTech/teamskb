\timing on
CREATE TABLE benchmark_docs (id integer PRIMARY KEY, title text NOT NULL, body text NOT NULL);
INSERT INTO benchmark_docs
SELECT n,
       'Knowledge note ' || n,
       CASE WHEN n % 1000 = 0
            THEN 'Acme renewal policy and contract exceptions for regional operations ' || n
            ELSE 'General operations handbook covering onboarding support and routine procedures ' || n
       END
FROM generate_series(1, 200000) AS n;
ANALYZE benchmark_docs;

\echo KEYWORD ILIKE, unindexed
EXPLAIN (ANALYZE, BUFFERS, SUMMARY)
SELECT id, title, body FROM benchmark_docs
WHERE title ILIKE '%' || 'Acme renewal policy' || '%'
   OR body ILIKE '%' || 'Acme renewal policy' || '%'
LIMIT 5;

\echo FULL TEXT, unindexed
EXPLAIN (ANALYZE, BUFFERS, SUMMARY)
SELECT id, title, body FROM benchmark_docs
WHERE to_tsvector('pg_catalog.english'::regconfig, COALESCE(title::text,''))
      @@ websearch_to_tsquery('pg_catalog.english'::regconfig, 'Acme renewal policy')
   OR to_tsvector('pg_catalog.english'::regconfig, COALESCE(body::text,''))
      @@ websearch_to_tsquery('pg_catalog.english'::regconfig, 'Acme renewal policy')
LIMIT 5;

CREATE INDEX benchmark_docs_title_search_idx ON benchmark_docs
USING gin (to_tsvector('pg_catalog.english'::regconfig, COALESCE(title::text,'')));
CREATE INDEX benchmark_docs_body_search_idx ON benchmark_docs
USING gin (to_tsvector('pg_catalog.english'::regconfig, COALESCE(body::text,'')));
ANALYZE benchmark_docs;

\echo FULL TEXT, matching expression GIN index
EXPLAIN (ANALYZE, BUFFERS, SUMMARY)
SELECT id, title, body FROM benchmark_docs
WHERE to_tsvector('pg_catalog.english'::regconfig, COALESCE(title::text,''))
      @@ websearch_to_tsquery('pg_catalog.english'::regconfig, 'Acme renewal policy')
   OR to_tsvector('pg_catalog.english'::regconfig, COALESCE(body::text,''))
      @@ websearch_to_tsquery('pg_catalog.english'::regconfig, 'Acme renewal policy')
LIMIT 5;
