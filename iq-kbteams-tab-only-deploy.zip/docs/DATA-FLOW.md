# Data flow and local persistence

Code-grounded operator inventory, checked 2026-10-05. This is not a privacy notice, legal review, provider commitment, or substitute for the selected provider's contract. See [PROVIDER-RETENTION-REVIEW-2026-10-05.md](PROVIDER-RETENTION-REVIEW-2026-10-05.md) for the implementation-specific provider comparison. Review both against the deployed configuration before publishing privacy/terms pages or enabling production sources.

## Request and answer flow

| Data | Where it goes | Why and handling |
| --- | --- | --- |
| Entra identity token | Teams tab or Bot Framework sign-in to the Go app; for OBO, the gateway exchanges the assertion with Microsoft Entra | The Go app validates tenant and user identity. Tokens are used in memory for the request. The gateway maintains a separate encrypted MSAL token cache on its persistent volume. |
| User question | Go app; enabled Microsoft Graph search endpoints; the user's PostgreSQL LOGIN when PostgreSQL search is selected; configured model provider | Graph receives the question as a search term. PostgreSQL receives a bound term or legacy query parameter, never generated SQL. The model receives the question with its prompt. The app does not save the question. |
| Retrieved source text | Go app memory; isolated parser over its private Unix socket for supported files; then configured model provider | The parser has no network and does not persist document text. The app selects at most six sources and bounds the assembled excerpt section to 80,000 characters (including source labels/formatting; question and prompt instructions are additional). PostgreSQL business rows are formatted as excerpts. |
| Model answer and citations | Go app response to the private tab; for personal bot messages, the Teams gateway sends the answer and source links back into the personal Teams conversation | The app holds the answer in memory and does not save it. Microsoft 365 may retain incoming personal bot messages and bot replies under the tenant's Teams retention and eDiscovery policies. Group/channel messages receive a private-tab handoff; the app does not post source-derived answers there. |
| Provider connectivity check | Configured model provider | Uses a fixed synthetic prompt and does not include a user question or source content. |

Enabled sources are searched with the asking user's delegated Microsoft access: personal OneDrive, configured SharePoint site libraries, the user's Outlook mailbox, the user's Teams chats, and channels in associated teams, including incoming shared channels where the user is a member. Optional PostgreSQL search uses a fresh verified-TLS connection authenticated as the user's mapped existing PostgreSQL LOGIN. Source queries and provider calls are bounded; source authorization remains with Graph or PostgreSQL.

## Model-provider exposure

For an answer, the configured provider receives the user's question, system instructions, and the retrieved excerpts needed to answer it. When PostgreSQL tools are configured, tool selection also sends the question and the approved tool labels, synonyms, capabilities, and filter labels; it does not send SQL or source rows at that stage. Citation URLs are excluded from the provider prompt and added to the app response after generation.

- OpenAI Responses requests set `store: false`.
- OpenAI-compatible Chat Completions requests include `store: false`, but behavior and retention depend on the selected compatible service and its implementation.
- Anthropic Messages requests do not include an application-level retention control.
- A custom OpenAI-compatible HTTPS endpoint may be a third-party service. The configured URL, model, provider, and successful-check marker are stored as app metadata; the API key is supplied through operator configuration or a mounted secret and is not stored in SQLite.

These request fields do not establish zero retention, no training, a data-residency region, deletion timing, or a legal basis. Confirm those points for the actual provider account, endpoint, model, and contract. Provider terms and behavior are outside the application's control.

## Persistent state on the host

SQLite in the `app_data` volume stores application metadata, not knowledge content:

- Tenant/user object IDs, verified email, admin assignment, reviewed PostgreSQL LOGIN mapping, and mapping review metadata.
- Enabled-source settings and configured SharePoint site URLs.
- Model provider, model, compatible-provider base URL, and successful-check fingerprint; no provider API key.
- Approved PostgreSQL query/profile definitions, labels, aliases, filter mappings, generated SQL, approvals, schema fingerprints, and profile-test status/error categories.
- Per-user PostgreSQL passwords as AES-GCM ciphertext with nonce. `APP_ENCRYPTION_KEY` is held outside the database.
- Daily ask counts, monthly provider-attempt counts, and content-free ask audit events (request ID, tenant/object actor, timestamp, outcome, and source count). Ask audit rows are written only after a request passes the daily per-user quota; repeated concurrency and quota rejections do not create rows. Each audit write has a two-second deadline. Audit rows are capped at 100,000 total, with the oldest rows removed first; the default 30-day retention (configurable from 1–3650 days) may remove rows sooner. Old daily counts are pruned during a later ask reservation after 31 days; prior-month attempt counts are pruned on a subsequent model-attempt reservation.
- Short-lived bridge replay nonces and the encryption-key check record.

The `gateway_cache` volume holds the MSAL cache encrypted with AES-GCM under the separate operator-managed gateway cache key. The Caddy data volume holds certificates and related TLS state. Database profiles, identity mappings, token cache, certificates, and backups persist until operators remove or expire them. Ask audit events, daily counts, and monthly attempt counts have the cleanup behavior described above; expired bridge replay nonces are removed on a later bridge request. Docker/Dokploy logs and backups are controlled by the operator's host and backup policies.

Application code does not intentionally write user questions, source documents/messages/rows, prompts, or model answers into SQLite or parser files. Go application logs are limited to startup/service errors and audit-cleanup failures; the host may retain container stdout/stderr. Verify runtime/framework logs and configure host log retention before enabling centralized log export.

## Deployment review items

Before a pilot, record the actual Microsoft cloud/tenant and Graph consent, enabled source families and scopes, model provider/account/region/model/base URL, provider retention and training terms, host and backup location/retention, container-log retention, audit retention, and who can access the host volumes and secrets. Publish privacy and terms pages reviewed for that deployment. This inventory cannot decide those organization-specific settings or contractual approvals.
