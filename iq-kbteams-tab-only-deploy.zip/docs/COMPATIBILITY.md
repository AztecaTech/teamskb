# Phase A compatibility record

Checked 2026-10-03. The following versions are pinned from current package metadata/documentation and built in the scaffold. Pin changes require repeating these checks.

| Area | Pin | Check |
|---|---|---|
| Go toolchain | `go1.27.1` | Downloaded automatically by Go and used by native build plus Docker build |
| OpenAI Go SDK | `github.com/openai/openai-go/v3 v3.69.0` | Module resolved; official SDK's Responses API is available |
| Anthropic Go SDK | `github.com/anthropics/anthropic-sdk-go v1.63.1` | Module resolved; official SDK's Messages API is available |
| OIDC | `github.com/coreos/go-oidc/v3 v3.20.0` | Module resolved |
| PostgreSQL | `github.com/jackc/pgx/v5 v5.11.0` | Fresh per-user password-authenticated connections and invoker-secure view profiles passed a disposable PostgreSQL 18 integration fixture over `sslmode=verify-full`; invoker views require PostgreSQL 15+; Azure Entra and generic PG18 OAuth remain unsupported/unverified |
| SQLite | `modernc.org/sqlite v1.60.1` | Module resolved; pure-Go driver |
| Teams SDK | `@microsoft/teams.apps 2.0.16` | Gateway TypeScript build and Node 24 image build passed |
| Teams JavaScript SDK | `@microsoft/teams-js 2.57.0` | Tab uses `app.initialize()` and obtains a fresh SSO token for server requests; production build passed |
| MSAL Node | `@azure/msal-node 7.0.1` | Gateway TypeScript build and Node 24 image build passed |
| Node base | `node:24-alpine@sha256:ebfe2f90462722a7a4de65e91990e97fe0d401c70e0e762c5b53302f905ec1c1` | App and gateway image builds passed |
| React / Vite / TypeScript | `19.3.0 / 8.3.2 / 7.0.2` | Lockfile install and production build passed; Docker build ran on Node 24 |
| Parser runtime | `python:3.12-slim@sha256:dddfd7e07f9d15aeeca61529320492139d21cac7f0070c00609243e51e4e0016` | Parser image build passed |
| Caddy | `caddy:2@sha256:13b7fbadd017b042956fddbceedeeea12bb1e560534f9b3df281269dbcc61813` | Local HTTPS reverse-proxy route passed |

Parser direct and transitive Python dependencies are pinned in `parser/requirements.txt`. JavaScript dependencies are pinned in npm lockfiles; Go module checksums are in `app/go.sum`.

## Relevant verified behavior

- Teams SDK documentation lists TypeScript, C#, and Python; the current TypeScript reference lists version 2.0.16. This project uses the documented TypeScript SDK and keeps business logic in Go. [SDK languages](https://learn.microsoft.com/en-us/microsoftteams/platform/teams-sdk/welcome) · [TypeScript reference](https://learn.microsoft.com/en-us/javascript/api/teams-sdk-typescript/?view=msteams-sdk-ts-latest)
- Teams tab SSO obtains additional Graph scopes through server-side OBO and requires consent for the requested delegated permissions. [Tab SSO/OBO](https://learn.microsoft.com/en-us/microsoftteams/platform/tabs/how-to/authentication/tab-sso-graph-api)
- TeamsJS SSO guidance calls `authentication.getAuthToken()` after `app.initialize()` and recommends obtaining tokens only when needed rather than storing them in the tab. [Tab SSO code](https://learn.microsoft.com/en-us/microsoftteams/platform/tabs/how-to/authentication/tab-sso-code)
- Teams personal-tab deep links use `https://teams.microsoft.com/l/entity/{appId}/{entityId}` with `webUrl` and `label` query parameters. The bot's static handoff uses the manifest app ID and the personal tab entity ID `assistant`. [Teams app deep links](https://learn.microsoft.com/en-us/microsoftteams/platform/concepts/build-and-test/deep-link-application)
- Graph DriveItem search supports delegated `Files.Read` as its least privileged work/school permission; search under `/me/drive` is therefore the first source boundary implemented. The same user token is exchanged through OBO and Graph checks access again when file content is downloaded. [DriveItem search permissions](https://learn.microsoft.com/en-us/graph/api/driveitem-search?tabs=http&view=graph-rest-1.0)
- SharePoint site lookup uses Graph's `GET /sites/{hostname}:/{relative-path}` endpoint, whose least delegated permission is `Sites.Read.All`; that scope is consented separately through the fixed SharePoint OBO profile. The app searches only the default document library for configured sites, with each request and download made using the signed-in user's delegated token. [Graph site-by-path permissions](https://learn.microsoft.com/en-us/graph/api/site-getbypath?view=graph-rest-1.0), [DriveItem content permissions](https://learn.microsoft.com/en-us/graph/api/driveitem-get-content?view=graph-rest-1.0)
- Teams private/group chat retrieval uses delegated `Chat.Read`, calls `/me/chats` and reads messages only in those chats. It checks at most ten chats and twenty most recent messages per chat, then ranks locally against question terms. All six enabled source families share a six-item per-answer cap, distributed evenly with no family receiving more than three items. [List chats](https://learn.microsoft.com/graph/api/chat-list?view=graph-rest-1.0), [List chat messages](https://learn.microsoft.com/en-us/graph/api/chat-list-messages?view=graph-rest-1.0)
- Teams channel retrieval uses a separate delegated OBO profile for `Team.ReadBasic.All`, `Channel.ReadBasic.All`, and `ChannelMessage.Read.All`. It traverses at most five associated teams, five channels per team, and twenty recent root messages per channel, with a twelve MiB aggregate response limit. Associated teams and `allChannels` include incoming shared channels the signed-in user belongs to; Graph authorizes message reads with that user's delegated token. Replies remain excluded. Graph supplies message `webUrl` citations, restricted to HTTPS `teams.microsoft.com`. [List associated teams](https://learn.microsoft.com/en-us/graph/api/associatedteaminfo-list?view=graph-rest-1.0), [List all channels](https://learn.microsoft.com/en-us/graph/api/team-list-allchannels?view=graph-rest-1.0), [List channel messages](https://learn.microsoft.com/en-us/graph/api/channel-list-messages?view=graph-rest-1.0), [chatMessage resource](https://learn.microsoft.com/en-us/graph/api/resources/chatmessage?view=graph-rest-1.0)
- Microsoft documents bot SSO for personal and group chats, but not channel scope. The design therefore requires a private authenticated tab handoff for channel use. [Bot SSO scope](https://learn.microsoft.com/en-us/microsoftteams/platform/bots/how-to/authentication/bot-sso-overview)
- PostgreSQL 18 OAuth depends on a server-side validator module. Azure PostgreSQL end-user OAuth through pgx has not passed an integration test, so generic PG18 OAuth remains unsupported. [PostgreSQL OAuth validators](https://www.postgresql.org/docs/18/oauth-validators.html)

These checks verify dependency availability and local build behavior. They do not verify Graph permission semantics against a tenant, real Teams authentication, Azure PostgreSQL integration, or provider compatibility with a configured OpenAI-compatible endpoint.
