# Model-provider data-retention review

Checked 2026-10-05 against the implementation and the providers' published commercial/API documentation. This is an engineering review, not legal advice, a contract review, or confirmation of any particular account's settings. The organization must choose and approve the actual provider, account, endpoint, model, and applicable terms.

## What IQ-kbteams sends

The answer request sends the user's question, system instructions, and selected excerpts from enabled Microsoft and optional PostgreSQL sources. It does not send citation URLs to the model. When PostgreSQL tool selection runs, it sends the question and approved profile/tool labels, synonyms, capabilities, and filter labels; it does not send SQL or result rows in that selection call. The administrator's provider test uses only a fixed synthetic prompt. See [DATA-FLOW.md](DATA-FLOW.md) for the full data inventory.

| Configured mode | Current request behavior in code | Published provider handling to verify |
| --- | --- | --- |
| OpenAI Responses | Sends `store: false` on every response request. | OpenAI documents that API data is not used to train models by default unless the customer opts in. Its standard abuse-monitoring logs may contain prompts/responses and are retained up to 30 days. `store: false` disables Responses application-state storage; it does not disable standard abuse monitoring. Modified Abuse Monitoring or Zero Data Retention require account-level eligibility/configuration and are not enabled by this application. [Data controls](https://developers.openai.com/api/docs/guides/your-data), [Responses API](https://developers.openai.com/api/reference/cli/resources/responses/methods/create). |
| Anthropic Messages | Sends a direct Messages API request with no application-supplied retention setting. | Anthropic's published standard commercial/API policy says inputs and outputs are automatically deleted within 30 days, subject to listed exceptions. Zero Data Retention is an organization-level arrangement and applies only to eligible APIs, features, and models. Models Anthropic designates as Covered Models require 30-day retention even where other ZDR arrangements exist, unless expressly authorized. Confirm current model eligibility and account terms. [Commercial/API retention](https://privacy.claude.com/en/articles/7996866-how-long-do-you-store-my-organization-s-data), [API retention and ZDR](https://platform.claude.com/docs/en/manage-claude/api-and-data-retention), [Covered Models](https://support.claude.com/en/articles/15425695-covered-models). |
| OpenAI-compatible endpoint | Sends Chat Completions with `store: false` to the administrator-configured HTTPS base URL. | "OpenAI-compatible" is a protocol shape, not a common data policy. This flag's effect, provider-side logging, training use, retention, residency, and subprocessors depend on the exact server/operator and contract. This may be a third-party hosted endpoint or an operator-run service. |

The provider/model names, compatible base URL, and a successful-check fingerprint are app metadata. The provider API key comes from operator configuration or a mounted secret and is not stored in SQLite. The administrator supplies the model name; the application does not verify model-specific retention eligibility or policy. The connection check proves only that one synthetic request succeeded; it does not test retention controls or contractual settings.

## Decision record required for a deployment

Before enabling user traffic, the service owner should record:

- Provider legal entity, plan/account, API endpoint and region, exact model/version, and any gateway or proxy between IQ-kbteams and the provider.
- Applicable commercial agreement and data-processing terms; whether prompts/outputs may be used for training or service improvement; standard abuse monitoring; retention/deletion periods; safety-review exceptions; subprocessors; and data residency.
- For OpenAI, the account/project's abuse-monitoring and storage controls, eligibility and actual enrollment for Modified Abuse Monitoring or Zero Data Retention, and whether the chosen endpoint/model is covered.
- For Anthropic, the commercial organization and API endpoint, current standard retention, whether ZDR was expressly enabled for this organization, and whether the selected model/features are eligible or require retention.
- For any compatible endpoint, the actual server implementation's behavior for `store: false`, its logs/backups, retention configuration, training terms, subprocessors, and deletion process.
- Named approver, review date, and re-review trigger when provider, model, account, endpoint, or contract changes.

No provider account or contract was available during this local implementation. The organization-specific provider contract/retention gate therefore remains open; do not infer approval from this review or from the request flags.
