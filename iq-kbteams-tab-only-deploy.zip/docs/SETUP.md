# Setup and operating notes

IQ-kbteams has a local Phase A–C implementation; it is not release-ready. Live Teams compatibility, tenant authorization, production database permissions, independent security and hostile-file reviews, and production load/backup validation remain open. Compose exposes only Caddy; Go, the Teams gateway, and the isolated document parser remain on private container networks. Caddy applies a same-origin resource policy, host-scoped HSTS, and framing permissions for Microsoft Teams and the current Microsoft cloud host domain; tenant install validation is still required. Caddy also limits public request bodies to 2 MiB and bounds upload/header read times; the Go app applies its own 1 MiB body and 15-second read limits. Compose applies baseline memory, CPU, and PID limits to Caddy, app, gateway, and parser. `.env.example` lists the overridable limits; size the host and tune them using production-representative load results before deployment. Bootstrap/provider/client secrets and encryption keys come from operator-managed .env values in local development, mounted secret files in the default multi-container Docker Compose deployment, or environment variables injected from .env by Dokploy Compose mode. In Dokploy single-container mode, the launcher filters environment variables passed to child processes; deployment administrators can still inspect the container environment. See [Dokploy deployment](DOKPLOY.md). SQLite stores only application metadata, settings, usage limits, and content-free audit events; it is not a knowledge source and does not hold business content. Connected Microsoft and PostgreSQL sources remain authoritative. The app encryption key and gateway token-cache key are different operator secrets, separate from each other and from encrypted per-user PostgreSQL credential records. Do not use the app key to encrypt the gateway token cache.

Review [DATA-FLOW.md](DATA-FLOW.md) before pilot configuration and privacy/terms publication. It distinguishes the application's local persistence from the content sent to Microsoft sources and the configured model provider; provider contracts and tenant retention settings still need operator review.

Compose reports the gateway healthy after its TCP listener accepts a connection, the parser healthy after its private Unix socket accepts a connection, and the app healthy after its bounded healthcheck receives `/health/ready` with SQLite available. The app waits for the gateway and parser before starting; Caddy waits for the app and gateway to become healthy before serving requests. An unhealthy dependency after startup is visible in `docker compose ps` and affects dependent operations.

## Start the self-hosted stack

1. Copy `.env.example` to `.env`, then set `PUBLIC_ORIGIN` to the public HTTPS origin and fill in the tenant, app registration, administrator, and app resource values. Compose reads `.env` automatically; keep it local because it is ignored by Git.
2. From the repository root, run `rtk powershell -NoProfile -File scripts/init-secrets.ps1`. It creates the default sibling `IQ-kbteams-secrets` directory with random encryption/bootstrap keys and empty provider-key and PostgreSQL DSN files. If `.env` uses a custom `IQKB_SECRETS_DIR`, set the same path in `$env:IQKB_SECRETS_DIR` before running the script.
3. Set the provider key in `model_api_key`. After creating the Entra app registrations, create `app_client_secret` and `bot_client_secret` in that secrets directory with their respective client secrets. Keep `postgres_dsn` empty if PostgreSQL is disabled. Read the generated `bootstrap_secret` from that directory for the one-time activation step in the admin tab.
4. Confirm public DNS points to this host and inbound ports 80 and 443 are available for Caddy. Run:

   ```powershell
   rtk docker compose config --quiet
   rtk docker compose up --build --detach
   rtk docker compose ps
   ```

   Check `https://<your-public-host>/health/ready` for `{"status":"ready"}`. Use `rtk docker compose logs --follow` to inspect service startup if a health check fails.
5. Stop services with `rtk docker compose down`. This keeps the named data and Caddy certificate volumes. Do not add `--volumes` unless you intend to delete application data and certificates.

This sequence builds and runs a configured deployment; it does not prove tenant consent, Teams SSO/OBO, Graph permissions, or a successful Teams app installation. Complete those checks in the configured tenant before a pilot.

## Register Microsoft Entra applications

Use a single-tenant setup for one organization's tenant. This implementation uses three distinct identifiers: `APP_CLIENT_ID` is the API app registration used by the tab, Go API, Graph OBO, and the bot's OAuth connection; `BOT_CLIENT_ID` is the bot identity registered with the Azure Bot resource; `TEAMS_APP_ID` is the Teams package ID. Do not substitute one for another. Put the API app's client secret in `app_client_secret` and the bot identity's secret in `bot_client_secret`.

The Teams package sets `bots[0].botId` and the `botid-...` resource suffix from `BOT_CLIENT_ID`; it sets `webApplicationInfo.id` from `APP_CLIENT_ID`. Microsoft recommends using the same app ID for the bot and SSO app, but documents this separate `webApplicationInfo.id` registration as supported. Keep the API scope and OAuth connection on `APP_CLIENT_ID`, and the bot resource ID on `BOT_CLIENT_ID`; live tenant validation is still required. See Microsoft's [bot SSO registration guide](https://learn.microsoft.com/en-us/microsoftteams/platform/bots/how-to/authentication/bot-sso-register-aad).

1. Create the API app registration in the target tenant and set its access token version to 2.0. Copy its Application (client) ID to `APP_CLIENT_ID` and its Directory (tenant) ID to `TENANT_ID`.
2. Under **Expose an API**, configure the API app's Application ID URI as `api://<lowercase-public-host>/botid-<BOT_CLIENT_ID>` and add a delegated scope named `access_as_user`; enable it and make admin consent available. Microsoft's combined bot-and-tab guidance specifies the `botid-{YourClientId}` form, while tab registration requires the hostname to match the hosted tab. Use the exact same URI in `APP_ID_URI`, the Teams manifest, and the bot OAuth connection. `APP_CLIENT_ID` remains the API audience in access tokens; the URI is the resource identifier and must not replace it. The package script checks this URI shape. See [tab SSO registration](https://learn.microsoft.com/en-us/microsoftteams/platform/tabs/how-to/authentication/tab-sso-register-aad) and [bot SSO registration](https://learn.microsoft.com/en-us/microsoftteams/platform/bots/how-to/authentication/bot-sso-register-aad).
3. Under **Expose an API > Authorized client applications**, preauthorize the trusted clients that users will use. For Teams, Microsoft's documented IDs include desktop/mobile `1fec8e78-bce4-4aaf-ab1b-5451cc387264` and web `5e3ce6c0-2b1f-4285-8d4b-75ee78787346`; Microsoft 365 web is `4765445b-32c6-49b0-83e6-1d93765276ca`. Add `access_as_user` to each authorization. Only preauthorize clients your organization trusts.
4. Add the API app's **Microsoft Graph delegated** permissions for each enabled source, then grant tenant admin consent: `Files.Read` for OneDrive; `Sites.Read.All` for SharePoint; `Mail.Read` for Outlook; `Chat.Read` for private/group chats; and `Team.ReadBasic.All`, `Channel.ReadBasic.All`, and `ChannelMessage.Read.All` for Teams channels. Channel search includes incoming shared channels where the signed-in user is a member. The gateway requests these as separate fixed OBO profiles. Grant only the permissions for sources you enable. Microsoft Graph may require administrator consent for organization-wide permissions such as `Sites.Read.All`; review the permission and consent prompt in the tenant before granting it.
5. If PostgreSQL identity mapping is needed, add the `verified_primary_email` access-token optional claim as described in [Optional PostgreSQL source](#optional-postgresql-source).
6. Create the bot identity registration and Azure Bot resource. Set `BOT_CLIENT_ID` to the bot registration's client ID, configure its bot secret in `bot_client_secret`, and set the Azure Bot messaging endpoint to `https://<your-public-host>/api/messages`. On the API app registration's **Authentication** page, add a **Web** platform redirect URI of `https://token.botframework.com/.auth/web/redirect` for the Bot Framework OAuth connection, as described by Microsoft's [bot SSO guide](https://learn.microsoft.com/en-us/microsoftteams/platform/bots/how-to/authentication/bot-sso-register-aad).
7. In the Azure Bot resource, add an OAuth connection using the API app client ID (`APP_CLIENT_ID`), its API app client secret, `TENANT_ID`, the API app's `APP_ID_URI` as the token exchange URL, and `APP_ID_URI/access_as_user` as the scope. The connection name must match `OAUTH_CONNECTION_NAME` (default `iqkbteams`). Test the connection in Azure Bot. These values follow [Microsoft's bot SSO OAuth connection guide](https://learn.microsoft.com/en-us/microsoftteams/platform/bots/how-to/authentication/bot-sso-register-aad).
8. Set `APP_CLIENT_ID`, `BOT_CLIENT_ID`, `TEAMS_APP_ID`, `APP_ID_URI`, and `TENANT_ID` in `.env`; add both client secret files to the Compose secrets directory. Then package the app as described below, upload it to the tenant app catalog, install it for a pilot user, and verify tab SSO, each enabled source check, and a personal bot sign-in/answer. Keep group/channel bot messages on the private-tab handoff path.

The exact Microsoft Entra and Azure Bot portal labels can change. This checklist describes the IDs, API scope, delegated source permissions, and OAuth values expected by the current code; tenant admin consent and live Teams behavior remain deployment gates.

## Rotate operator secrets

- After changing `model_api_key` or `postgres_dsn`, recreate the app so it reads the new file: `rtk docker compose up --detach --force-recreate app`.
- After changing `app_client_secret` or `bot_client_secret`, recreate the gateway: `rtk docker compose up --detach --force-recreate gateway`.
- `gateway_cache_key` encrypts only the disposable MSAL token cache. If it changes, recreate the gateway; on its next token-cache access, an old cache that fails authentication is discarded and can be repopulated from a new OBO request. The gateway test covers stale-cache removal after key rotation.
- `bridge_hmac_key` must match in the app and gateway. Change its file and recreate both services together with `rtk docker compose up --detach --force-recreate app gateway`; bridge requests may fail while the services restart.
- Do not replace `app_encryption_key` in place. It protects stored PostgreSQL credentials and is checked against the database at startup; a mismatched key prevents readiness and cannot decrypt saved credentials. Keep it paired with database backups. There is no online re-encryption workflow in this implementation.
- `bootstrap_secret` is read by the app at startup and only used for initial activation. If it changes before activation, recreate the app; it does not reset an already activated workspace.

## Build the Teams app package

The manifest template uses the current generally available Teams v1.29 schema and includes the required color and outline PNG assets. Build an installable package after registering the app IDs and publishing operator-reviewed privacy and terms pages:

PowerShell does not import values from `.env`. Set these five `$env:` values in the current shell from your configured `.env`, or replace each parameter below with its quoted value before running the command.

```powershell
rtk powershell -NoProfile -File scripts/package-teams-app.ps1 `
  -TeamsAppId $env:TEAMS_APP_ID `
  -BotClientId $env:BOT_CLIENT_ID `
  -AppClientId $env:APP_CLIENT_ID `
  -AppIdUri $env:APP_ID_URI `
  -PublicOrigin $env:PUBLIC_ORIGIN `
  -PrivacyUrl 'https://your-domain.example/privacy' `
  -TermsOfUseUrl 'https://your-domain.example/terms' `
  -OutputPath '.\\work\\iq-kbteams.zip'
```

The packaging script validates GUIDs, HTTPS URLs, icon PNG dimensions, bot scopes, and unresolved manifest placeholders. It refuses to overwrite an existing ZIP. It does not invent or host legal documents; supply public URLs whose contents have been reviewed for your deployment. The package is not proof that tenant consent, SSO/OBO, Graph permissions, or a Teams installation has been validated.

Run the synthetic package validation before preparing a tenant package:

```powershell
rtk powershell -NoProfile -File scripts/validate-teams-package.ps1
```

## Current admin setup flow

1. Configure tenant and app registration values, secret files, and a publicly reachable HTTPS origin as described by `.env.example` and Compose. For Docker, `rtk powershell -NoProfile -File scripts/init-secrets.ps1` creates random local keys plus empty `model_api_key` and `postgres_dsn` files in the same default sibling directory Compose uses. Set the model API key in its file; leave the PostgreSQL DSN empty when that source is disabled. Add the Entra client secret files after app registration. The script refuses to overwrite existing files.
2. Sign in as the configured administrator in the Teams tab. The tab gets an SSO token on demand and does not persist it in browser storage.
3. Set the provider API key in `MODEL_API_KEY` for local development or in the Docker `model_api_key` secret file. Set `MODEL_MONTHLY_ATTEMPT_LIMIT` to the desired positive attempt count (default `10000`). This shared UTC-month count includes ask generation, PostgreSQL tool selection, and provider connectivity checks; failed calls count, and it does not estimate tokens or provider spend. Save the provider and model metadata in the admin setup panel. The API key is read from operator configuration, never returned to the browser, and never stored in SQLite. Run the provider check; it sends only a fixed synthetic prompt, not user content.
4. Enable any combination of personal OneDrive, up to five configured SharePoint Online sites, Outlook mail, Teams private/group chats, and Teams channels. OneDrive is bounded to the signed-in user's `/me/drive`. SharePoint searches each configured site's default document library using the asker's delegated token and requires `Sites.Read.All`. Outlook searches the signed-in user's /me/messages sender, subject, and body text with Mail.Read using Graph message search; attachments and shared mailboxes are excluded. See Microsoft Graph [list messages](https://learn.microsoft.com/en-us/graph/api/user-list-messages?view=graph-rest-1.0) and [message search](https://learn.microsoft.com/en-us/graph/search-query-parameter) documentation. Teams chat search uses `Chat.Read` and checks ten chats with twenty recent messages each. Channel search uses `Team.ReadBasic.All`, `Channel.ReadBasic.All`, and `ChannelMessage.Read.All`, then checks up to five associated teams, five channels per team, and twenty recent root messages per channel. It includes incoming shared channels when the signed-in user is a member; replies are excluded. The admin check and final activation verify enabled source access.
5. Enter the one-time bootstrap secret and activate. The activation is bound to a tested provider configuration and enabled source. Activation is a one-way operation with no reset endpoint, but admins can reconfigure the provider and sources afterward. Saving provider settings clears its successful-check marker, so asks remain disabled until the provider is checked again; run each enabled source's check after changing its settings.
6. Ask a question from the private tab. The service searches each enabled source as the signed-in user, retrieves no more than six files or messages total per ask, extracts text in the offline parser, and returns an answer with source citations. When all six source families are enabled, each receives one candidate slot. Parser limits include a 24 MiB input cap, archive expansion/entry-count and output-text caps, and a 20-second wall-clock extraction deadline. Questions, source text, and answers are not stored by IQ-kbteams. Each user has a 100-request daily quota and an early ask burst limit of 10 requests, refilling at one request per second. Ask and admin provider-check routes also share a limit of ten concurrent model-related requests total and two per user; excess requests are rejected immediately with HTTP 429. Content-free audit events are capped at 100,000 rows and retained for `AUDIT_RETENTION_DAYS` (default 30 days, allowed range 1–3650); the app prunes expired events at startup and hourly while running.
7. Configure an Entra OAuth connection for the Teams bot with `APP_CLIENT_ID` and its client secret, `TENANT_ID`, `APP_ID_URI` as the token exchange URL/resource, and the exposed delegated `access_as_user` scope. Set `OAUTH_CONNECTION_NAME` to that connection name (default `iqkbteams`). The bot asks users to sign in in personal chat, then submits their question and token to the same per-user endpoint used by the tab. Group chats and channels receive only a private-tab handoff. Validate the OAuth connection, API scope, and SSO in an installed Teams app before pilot use.

## Optional PostgreSQL source

- The Compose app reads the PostgreSQL DSN from the `postgres_dsn` secret in `IQKB_SECRETS_DIR`. Create that file even when PostgreSQL is disabled; leave it empty to disable the source. When enabled, use a DSN with `sslmode=verify-full` and a trusted `sslrootcert`. IQ-kbteams refuses unverified PostgreSQL transports.
- IQ-kbteams does not create or modify organizational database tables, views, roles, grants, or policies. Have a DBA review a fixed SELECT catalog entry over existing authorized data; [schema.sql](postgres/schema.sql) is a query example only. The DBA must verify that existing views/functions preserve the intended per-login authorization semantics.
- An admin can run **Discover accessible schema** after saving their own mapped login password. Discovery uses that login in a verified-TLS, read-only transaction and returns only readable relation, column, primary/unique key, and foreign-key endpoint metadata; it reads no table rows and omits constraints whose endpoints/columns are not readable. Profiles can map an admin-named entity lookup or text search with typed return fields and confirmed aliases, plus an optional selected text field containing HTTPS source links. Unsafe or non-HTTPS database values are omitted from citations. A related-list profile selects one discovered child-to-parent foreign key, references a saved entity-lookup profile for the parent, and configures typed filters whose business labels map to explicit database values. The preview shows both fixed statements (parent resolution and child list), bound parameters, output fields, and permission boundaries before saving with DBA approval. Runtime resolves the parent under the asking user's LOGIN and asks for clarification when the match is ambiguous; the child query runs only for one visible parent. PostgreSQL 15+ views are usable only when every view in the dependency chain is invoker-secure and dependencies use immutable built-in functions/operators; owner-executed views, unsafe functions, and owner-owned RLS tables without forced RLS are rejected. A view's selected key is checked for nulls and duplicates on each profile-access check; this scans the view under the five-second statement timeout and can be expensive. Prefer a base table with a unique index for large data sets.
- Each user must have an admin-reviewed mapping from their tenant/object ID and verified Entra email to an existing PostgreSQL LOGIN identity. Each user supplies that login's password; IQ-kbteams tests it, encrypts it at rest, and opens a fresh connection as that login for each query. There is no shared execution login or role switching. A missing/ambiguous mapping or credential disables only PostgreSQL retrieval.
- PostgreSQL mapping requires Entra to emit `verified_primary_email` in the API access token. Configure that optional claim on the API app registration under Token configuration for Access tokens, or merge this fragment into the app registration manifest's existing `optionalClaims` property:

  ```json
  {
    "optionalClaims": {
      "accessToken": [
        { "name": "verified_primary_email", "essential": false }
      ]
    }
  }
  ```

  IQ-kbteams uses the signed `oid` as the identity key and the authoritative email claim only as an additional mapping check; if the claim is absent, the user cannot use PostgreSQL. Do not substitute `email` or UPN, which Microsoft documents as mutable and unsuitable for authorization or durable identity.
- The versioned admin catalog keeps legacy fixed SELECT statements compatible and supports single-table entity profiles. Before model selection or profile listing, the app checks the current user's mapping, password, relation/column visibility, and profile schema fingerprint; unavailable profile labels are omitted. Profile selectors receive only reviewed profile metadata and an explicitly allowed search term. Exact key/label matches participate in entity resolution, ambiguous results ask the user to clarify, and typed profile attributes remain separate from text documents. Queries run over verified TLS in read-only transactions with five-second statement and one-second lock timeouts, plus bounded result sizes.
- Legacy fixed-query entries still search with the full question string. Profile queries use model-selected terms and produce separate business records. Text-search profiles can select keyword matching or PostgreSQL full-text search with a validated language configuration. Related-list profiles use one reviewed FK and explicit typed filters. A disposable 200,000-row PostgreSQL benchmark compares the compiled keyword and full-text predicates with and without matching GIN indexes; the script, SQL, and measured fixture results are in [the PostgreSQL revalidation record](POSTGRESQL-MAPPING-REVALIDATION-2026-10-05.md). These results are not production latency estimates. Operators still need to verify the chosen language configuration and query/index behavior with their own schema and data. Profile queries recheck unique-key, type, relation, FK, row-security, and current-user column-access metadata before execution; results remain bounded by the standard statement and result limits. A PostgreSQL profile requires passing tests from two distinct mapped users before activation.
- PostgreSQL OAuth is unsupported. Azure Entra PostgreSQL delegated tokens and identity mapping are also unverified and unsupported; use per-user PostgreSQL passwords for the supported mode. `integration-fixture.sql` is for disposable testing only and provisions two login users to verify distinct RLS and column permissions.

## SQLite backup and restore

- The app image includes `/iqkb-db`. A backup uses SQLite `VACUUM INTO` to make a consistent snapshot, including committed WAL data, while the app is running. Backups are created as new files with mode `0600`; choose a unique path for each snapshot.
- Create and export a backup:

  ```sh
  docker compose exec app /iqkb-db backup /var/lib/iqkb/backup-20261003.sqlite
  docker compose cp app:/var/lib/iqkb/backup-20261003.sqlite ./backup-20261003.sqlite
  ```

- Protect the exported database as application metadata and encrypted per-user PostgreSQL credentials. Provider API keys and bootstrap credentials are kept in operator-managed secret files, not in SQLite. Retain the matching `app_encryption_key` separately and securely to decrypt PostgreSQL credentials and pass the startup key check; a restored database will fail startup key verification if that key is missing or changed.
- To restore, first copy a validated backup into the persistent app volume, then stop the app and run the restore command:

  ```sh
  docker compose cp ./backup-20261003.sqlite app:/var/lib/iqkb/restore.sqlite
  docker compose stop app
  docker compose run --rm --no-deps --entrypoint /iqkb-db app restore /var/lib/iqkb/restore.sqlite
  docker compose start app
  ```

- Restore checks SQLite integrity and schema version, refuses while `config.sqlite-wal`, `config.sqlite-shm`, or `config.sqlite-journal` exists, and preserves the previous database as `config.sqlite.pre-restore`. Keep the app stopped until the restore command finishes. The app handles Compose's SIGTERM by draining HTTP requests and closing SQLite; if an abrupt shutdown leaves sidecars, start the app with its matching encryption key to let SQLite recover, then stop it normally before restoring. Verify readiness and the expected configuration before removing the pre-restore file or restore snapshot. The database and app encryption key must be backed up as a pair.

## Provider data handling

The configured model provider receives the question and extracted source excerpts for each answer request. `Store:false` is sent where the provider API supports that option; it does not establish the provider's retention policy. Before enabling a provider, the operator must review that provider's current terms, retention, and data-processing settings. Provider secrets are configured outside the app UI and are never returned by the admin API. Provider error details are not returned to end users.

## Required tenant setup

- A Microsoft 365 tenant and operator-supplied Entra tenant ID, administrator object ID, app registrations, credentials, and consent for enabled delegated scopes.
- Public DNS and reachable HTTPS for Teams callbacks and tab hosting.
- Docker Engine and a protected persistent data location.
- An administrator-selected model provider with a suitable data-processing agreement and credentials.

## Known boundaries

- OneDrive, administrator-configured SharePoint Online site libraries, the signed-in user's Outlook mailbox, the user's private/group Teams chats and joined channels, and an optional admin-catalogued PostgreSQL source are connected. Personal bot messages can request sign-in and use the authenticated per-user answer route; group and channel bot messages receive a private-tab handoff. Retrieved source excerpts are sent to the configured model provider when used for an answer.
- The app answers in a personal bot conversation only after it receives an API-audience `access_as_user` token and the API verifier accepts its tenant, user, and trusted client. Group and channel activity remains a private tab handoff. Shared answers require complete audience enumeration and per-member source reauthorization. Uncertain proof must produce a private handoff.
- Previously posted Teams messages cannot be withdrawn by this application after later permission or membership changes.
- PostgreSQL uses independent per-user LOGIN connections with passwords and verified TLS. Azure Entra delegated database OAuth has not been verified and remains unsupported. Validate two real login accounts, row/column grants, and organizational query semantics before enabling this source.
- Live Teams behavior, OBO, Graph access, and provider behavior require tenant credentials and real service checks. Local mock tests and builds do not establish compatibility or permission enforcement.
