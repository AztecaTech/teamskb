# PostgreSQL mapping implementation review — 2026-10-05

## Assessment

Changes against initial commit `93f210c` need correction before deployment. This is a partial single-table mapping increment, not completion of the agreed database-aware querying plan. An independent Astra review corroborated the database findings. No SQL injection or per-user LOGIN bypass was demonstrated in the reviewed implementation; identifiers are quoted, values are bound, and execution retains per-user TLS/read-only checks.

## Findings

### R1 — P1: model instructions prohibit the required profile term

`app/internal/answer/model.go:23` still requires exactly `tool` and `limit`, forbids parameter values, and says to bind the original question. New profile selections require a separate `term` in `app/internal/postgres/catalog.go:83–88`. A model obeying the system instructions therefore produces a rejected profile selection, preventing the main profile-query path from working. The profile selector tests supply hand-authored JSON with `term`, so they do not catch the mismatch.

Fix: align the model instructions and provider contract tests with both legacy and profile schemas. Exercise the actual selector SDK request and parser together, preserving rejection of SQL/identifiers and unapproved fields.

### R2 — P1: result budgets hide entity ambiguity

`app/cmd/iqkb/ask.go:419–434` queries with `min(selection.Limit, limits[5])` and detects ambiguity only if more than one returned record exists. All six enabled sources allocate one PostgreSQL slot; a model can also choose limit one. Multiple matching entities then appear unique, and the app generates an answer from the first row without clarification.

Fix: separate entity-resolution candidate checking from the answer-evidence budget. Fetch at least two candidates, or explicitly verify unique resolution, before treating a match as identified. Test duplicate names with all six sources enabled and with selector limit one.

### R3 — P2: entity ID equality does not participate in matching

`app/internal/postgres/profile.go:124–131` puts key/label equality in `ORDER BY`, but `WHERE` tests only configured search columns. For integer key `id=42` and searchable `name`, searching `42` misses the record unless the name also contains that text. Integer keys cannot be added to the search list under its current text-type check.

Fix: make exact key/label predicates part of entity matching, then apply the explicitly configured fallback. Test numeric and UUID identifiers independently of display-name contents.

### R4 — P2: invalidated test evidence can be restored by an old request

`app/cmd/iqkb/postgres_admin.go:473–478` runs a remote query and then saves its result without rechecking the tested credential/binding generation. Concurrent credential deletion or replacement clears existing tests, but an older in-flight request can subsequently insert `passed` again. `app/cmd/iqkb/main.go:779` counts it without checking current credential existence/generation. This compromises the two-user validation gate; it does not demonstrate bypass of actual query-time database permissions.

Fix: store evidence transactionally only if the profile, binding, and credential generations still match the tested snapshot. Count only current evidence at activation. Test deletion/rotation while a controlled profile test is paused.

### R5 — P2: profile metadata is not filtered for the asking user

`app/cmd/iqkb/postgres_admin.go:409–425` exposes every profile's ID, label, version, and capability to any authenticated tenant user, including unmapped users. `app/cmd/iqkb/ask.go:177` also selects from the complete catalog before checking that user's database mapping or profile access. Consequently private business labels/descriptions can be disclosed or sent to the model even where that user cannot query the source.

Fix: define and enforce the permitted profile-metadata boundary consistently for listing, self-tests, and model selection. Derive availability from the user's current authenticated database permissions plus approved mappings; admin discovery access must not imply user access. SQL and rows are not exposed by the listing, but metadata visibility still violates the intended filtering requirement.

### R6 — P2: discovery pagination drops a relation

`app/internal/postgres/discovery.go:88` uses the omitted 101st relation as the next cursor. The next page's strict `>` predicate skips it. Larger schemas silently lose one relation per page transition.

Fix: use the last returned relation as the exclusive cursor. Test at least 101 and 202 accessible relations and verify none are missing or duplicated.

### R7 — P2: PostgreSQL timezone timestamps are rejected

`app/internal/postgres/profile.go:280` lacks layouts for hour-only offsets such as `2026-10-05 12:00:00+00` or `-07`. Search casts attributes to text and rejects these otherwise valid mapped timestamp values. A temporary focused Go test reproduced rejection of both forms; it was removed after the review. PostgreSQL date/time output also depends on session settings. [PostgreSQL date/time output](https://www.postgresql.org/docs/current/datatype-datetime.html#DATATYPE-DATETIME-OUTPUT).

Fix: prefer native typed scanning or deterministic query/session formatting. Test real PostgreSQL timestamp/date values, timezone offsets, fractional seconds, nulls, and relevant session settings.

### R8 — P2: fingerprints depend on unspecified metadata row order

`app/internal/postgres/profile.go:209–246` hashes column metadata in result iteration order, but the query has no `ORDER BY`. Sorting the array passed to `ANY` does not order query output. An unchanged relation can therefore be marked stale when plan/result order changes. [PostgreSQL ordering guarantees](https://www.postgresql.org/docs/current/queries-order.html).

Fix: sort collected fingerprint components or order the metadata query explicitly. Test identical metadata presented in different row orders.

### R9 — P2: Teams bot is incompatible with the extended ask response

`gateway/src/bot-message.ts:96` expects `answer` to be a string. New ambiguity responses contain `clarification` instead, so users receive the generic error rather than the question/candidates. A local fixture using the actual compiled gateway handler reproduced this behavior. The same handler still caps citations at five, despite the new six-source evidence cap, so an answer citing S6 can lose its source listing.

Fix: handle the clarification response explicitly and keep citation limits consistent with the API. Test both new response cases through the personal bot handler.

### R10 — P2: UI corrupts valid identifiers containing periods

`frontend/src/main.tsx:341` separates schema/table with `split('.', 2)`, while option values concatenate those names with a period. PostgreSQL permits quoted identifiers containing periods, and the backend compiler accepts them. Selecting such a discovered table reconstructs the wrong identifiers and fails saving the mapping.

Fix: use a structured selection or opaque option key, keeping schema and relation as separate fields. Test a schema and relation containing periods and other quoted-identifier characters.

## Scope and validation

The increment discovers relation/column metadata and builds entity lookup over a single base table. It does not discover/expose keys and FK relationships as promised, support reviewed related-record queries or typed filters, compare full-text retrieval, or implement multilingual search. The frontend forces every return column to `text`, despite the backend's broader typed attribute contract. Generated SQL appears after saving rather than being previewed before approval. These are scope/UX gaps to resolve or explicitly narrow with the user; they should not be described as completion of the full plan.

Independent checks: `go test -count=1 ./...`, `go vet ./...`, frontend production build, and gateway tests passed. Gateway reported 16 passed and one Windows Unix-socket skip. Host Node is 22.23.2, whereas the project specifies Node 24. Existing tests omit the important integrated scenarios above. Two focused probes reproduced timestamp rejection and bot clarification loss.

Docker Desktop's Linux engine failed to respond normally and eventually returned HTTP 500 for `/info`; new PostgreSQL integration and Docker validations could not run. No engine restart, real-service mutation, production deployment, push, or implementation fix was performed. The temporary Go reproduction file was removed; the bot reproduction remains ignored under `work/`. Existing local preview configuration/data were untouched.
