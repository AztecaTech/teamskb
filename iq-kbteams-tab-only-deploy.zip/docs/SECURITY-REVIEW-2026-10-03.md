# Security review — 2026-10-03

> Historical first-pass snapshot. The implementation subsequently added fixes for SEC-01 through SEC-04. See `SECURITY-REVALIDATION-2026-10-03.md` for the follow-up dummy-data checks and current review status. The findings below describe the earlier code, not the current implementation.

## Summary

Focused, read-only review of the current Go backend, Teams gateway, frontend, parser, and deployment. Implementation is still changing; findings describe the inspected snapshot. This is not a penetration test or a completed formal threat model.

All four medium-severity findings from this focused review have local follow-up fixes. No critical authentication bypass was identified in the reviewed paths; that does not establish that every path is secure or replace an independent audit.

Existing controls include tenant-specific token validation, stable tenant/object identity, encrypted stored credentials, actual per-user PostgreSQL authentication, read-only transactions, bounded query results, and an offline parser container. Group/channel requests currently receive a private handoff instead of source-derived answers, which avoids exposing private evidence to an unverified audience.

## Findings

### SEC-01 — Medium: concurrency and model-attempt limits are missing

Status: fixed in follow-up. Ask and admin provider-check routes share an admission gate allowing at most 10 simultaneous requests total and 2 for one user per application process; excess work is rejected immediately. Every ask-model call (including PostgreSQL tool selection), and each admin provider connectivity call, atomically reserves one count against a persistent UTC-month cap. `MODEL_MONTHLY_ATTEMPT_LIMIT` defaults to 10,000. Failed provider calls consume a reservation; this is an attempt count, not a monetary spend cap. Local tests cover concurrent admission, shared-route admission, and budget exhaustion. Multi-process deployments need a shared admission coordinator; the supported Compose topology runs one app instance.

Original evidence at review time: `app/cmd/iqkb/usage.go` limited each user to 100 asks per day, but there was no concurrency gate or monthly model-attempt counter. PostgreSQL tool selection plus answer generation could invoke the provider twice for one ask, and provider checks were unaccounted.

### SEC-02 — Medium: slow request bodies lack a read deadline

Status: fixed in follow-up. The public Go server now enforces a 15-second read timeout and a 180-second write timeout; the ask processing deadline is 150 seconds. A regression test asserts the configured timeout relationship. Slow-body behavior still needs verification through the deployed Caddy path.

Original evidence at review time: the public server had header and idle timeouts but no body read timeout, and ask body reading preceded the processing timeout. A size limit alone did not limit how slowly bytes arrived.

Original impact: a client could retain request resources by sending a body slowly. Deployed-proxy behavior remains to be verified.

Original fix recommendation: add a bounded request-body read deadline and suitable server write timeout, allowing the legitimate 150-second processing window. Verify protection through the deployed proxy. [Go HTTP timeout semantics](https://pkg.go.dev/net/http#Server).

### SEC-03 — Medium: model-provider redirects are unrestricted

Status: fixed in follow-up. Provider HTTP clients now return redirect responses without following them. Regression tests verify both 307 and 308 redirects fail and the destination receives no request.

Original evidence at review time: `app/internal/answer/model.go` created a default HTTP client without `CheckRedirect`; initial compatible-provider URLs require HTTPS, but redirects were not checked.

Original impact: a configured provider endpoint returning a redirect could cause requests containing retrieved evidence to reach another destination or an HTTP endpoint. This required provider behavior or compromise; ordinary users could not select an arbitrary endpoint.

Original fix recommendation: reject provider redirects and require the canonical endpoint in configuration. Test 307/308 responses with synthetic evidence and assert that the destination receives no request. This finding was based on source inspection and [Go client redirect behavior](https://pkg.go.dev/net/http#Client), not a completed runtime reproduction.

### SEC-04 — Medium: credential save can race with identity remapping

Status: fixed in follow-up. After the database login check, password storage now opens a SQLite transaction, re-reads the identity binding, verifies the database identity is unchanged, and stores the encrypted credential in that same transaction. Identity remapping/deletion uses a transaction that deletes the credential together with the binding update. Regression tests verify changed bindings reject storage and current bindings persist successfully.

Original evidence at review time: the credential handler read a binding, performed a database login check, then stored the password without re-reading the binding. A remap during the network check could therefore be followed by a stale save.

## Verification and remaining release gates

- Production-only npm audits for the gateway and frontend reported zero listed vulnerabilities. Follow-up scans on 2026-10-03: `govulncheck ./...` reported no Go vulnerabilities, and `pip-audit -r parser/requirements.txt` reported no known vulnerabilities in the pinned parser requirements. These are dependency database scans, not a security audit.
- No live Microsoft tenant, external PostgreSQL permission suite, or adversarial deployment test was performed.
- Verify wrong-tenant/wrong-audience rejection, actual Teams SSO/OBO claims, revoked Microsoft access, PostgreSQL grants/RLS with separate LOGIN users, and concurrent identity remapping under the deployed database/runtime.
- Keep shared answers private until audience authorization is implemented and tested for every evidence item. Email matching is an account-binding aid, never permission proof.
- Verify retrieved documents/messages cannot persuade the model to exceed approved tools or disclose secrets. Authorization and SQL restrictions must remain outside model decisions.
- Confirm what evidence each configured AI provider receives and its retention settings before production use.
- Content-free audit events now expire according to `AUDIT_RETENTION_DAYS` (default 30, hourly cleanup plus cleanup at startup); local tests cover the date cutoff and index migration. Confirm the organization's approved retention period before deployment.
- Independently verify the new per-process admission gate and persistent monthly attempt counter under expected load, and configure an appropriate attempt ceiling for the chosen models/provider pricing. The ceiling counts requests, not tokens or cost.
- Caddy now sets a restrictive same-origin CSP, Teams-compatible frame ancestors, `nosniff`, `no-referrer`, and host-scoped one-year HSTS. Syntax validation and a disposable pinned-image HTTPS response-header check pass locally; rendering inside Teams still needs tenant/client validation. No exploitable frontend injection sink was identified during this pass. Compose now applies configurable memory, CPU, and PID limits to Caddy, app, gateway, and parser. Tune them after production-representative load measurements.

SQLite remains local app metadata and encrypted-credential storage. It is not a copied knowledge database, and adding MongoDB would not resolve these findings.
